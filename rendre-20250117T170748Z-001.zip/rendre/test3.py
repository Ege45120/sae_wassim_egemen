import pandas as pd
import folium
import tkinter as tk
from tkinter import ttk
import os
import glob
import webbrowser
import json

def load_data():
    # Charger le fichier CSV
    csv_path = "fusion_filtre_departements_regions_2024-2025.csv"
    data = pd.read_csv(csv_path)
    
    # Convertir les dates
    if 'AAAAMMJJ' in data.columns:
        data['Date'] = pd.to_datetime(data['AAAAMMJJ'], format='%Y%m%d', errors='coerce')
    
    # Filtrer les dates où il y a du verglas
    verglas_dates = data[data['VERGLAS'] == 1]['Date'].dt.strftime('%Y-%m-%d').unique()
    
    # Charger les dates dans la liste déroulante
    date_dropdown['values'] = verglas_dates
    if len(verglas_dates) > 0:
        date_dropdown.set(verglas_dates[0])  # Sélectionner la première date par défaut
    else:
        date_dropdown.set("Aucune date disponible")

def generate_map():
    # Récupérer la date sélectionnée
    selected_date = date_dropdown.get()
    if selected_date == "Aucune date disponible":
        show_message("Aucune date disponible avec des cas de verglas.")
        return
    
    # Charger le fichier CSV
    csv_path = "fusion_filtre_departements_regions_2024-2025.csv"
    data = pd.read_csv(csv_path)
    
    # Convertir les dates
    if 'AAAAMMJJ' in data.columns:
        data['Date'] = pd.to_datetime(data['AAAAMMJJ'], format='%Y%m%d', errors='coerce')

    # Filtrer les données pour la date sélectionnée
    filtered_data = data[data['Date'] == selected_date]
    
    # Filtrer les données de verglas
    verglas_data = filtered_data[filtered_data['VERGLAS'] == 1]

    # Si aucune donnée de verglas pour cette date
    if verglas_data.empty:
        show_message(f"Aucun cas de verglas trouvé pour la date {selected_date}.")
        return

    # Dossiers GeoJSON
    geojson_chemin_departements = "fichiers_geojson"
    geojson_chemin_regions = "region_geojson"
    
    if zone_var.get() == "Département":
        geojson_files = glob.glob(os.path.join(geojson_chemin_departements, "*.geojson"))
        verglas_by_zone = verglas_data.groupby("NOM_USUEL")['VERGLAS'].count()
        geojson_key = 'nom'  # Clé dans le GeoJSON correspondant aux départements
    elif zone_var.get() == "Région":
        geojson_files = glob.glob(os.path.join(geojson_chemin_regions, "*.geojson"))
        verglas_by_zone = verglas_data.groupby("REGION")['VERGLAS'].count()
        geojson_key = 'nom'  # Clé dans le GeoJSON correspondant aux régions
    else:
        show_message("Choix invalide")
        return
    
    # Créer une carte
    Carte = folium.Map(location=[47, 1], zoom_start=6, tiles='openstreetmap', control_scale=True)
    
    # Ajouter les zones géographiques colorées
    for fichier in geojson_files:
        with open(fichier, 'r') as f:
            geojson_data = json.load(f)

        if 'features' in geojson_data:
            for feature in geojson_data['features']:
                # Obtenir le nom de la zone (département ou région)
                zone_name = feature['properties'].get(geojson_key, 'Inconnu')
                
                # Vérifier si la zone est dans les données de verglas
                if zone_name in verglas_by_zone:
                    count = verglas_by_zone[zone_name]
                    color = 'red' if count > 10 else 'orange' if count > 5 else 'green'
                    tooltip_text = f"{zone_name}: {count} cas de verglas"
                else:
                    color = 'blue'  # Si aucun verglas, tout est en bleu
                    tooltip_text = f"{zone_name}: Aucun verglas"
                
                folium.GeoJson(
                    feature,
                    style_function=lambda x, col=color: {
                        'fillColor': col,
                        'color': 'black',
                        'weight': 1,
                        'fillOpacity': 0.6,
                    },
                    tooltip=tooltip_text
                ).add_to(Carte)
    
    # Enregistrer la carte et l'afficher
    carte = "carte_verglas.html"
    Carte.save(carte)
    webbrowser.open(carte)

def show_message(message):
    # Fenêtre pop-up pour afficher un message
    message_window = tk.Toplevel(root)
    message_window.title("Information")
    ttk.Label(message_window, text=message, wraplength=400).pack(padx=10, pady=10)
    ttk.Button(message_window, text="OK", command=message_window.destroy).pack(pady=5)

# Interface graphique avec Tkinter
root = tk.Tk()
root.title("Zones de Verglas")

# Variables
zone_var = tk.StringVar(value="Département")

# Widgets
ttk.Label(root, text="Sélectionnez une date :").grid(row=0, column=0, padx=10, pady=5)
date_dropdown = ttk.Combobox(root, state="readonly", width=20)
date_dropdown.grid(row=0, column=1, padx=10, pady=5)

ttk.Label(root, text="Choisissez la taille de la zone géographique :").grid(row=1, column=0, padx=10, pady=5)
ttk.Radiobutton(root, text="Département", variable=zone_var, value="Département").grid(row=1, column=1, sticky="w")
ttk.Radiobutton(root, text="Région", variable=zone_var, value="Région").grid(row=2, column=1, sticky="w")

generate_button = ttk.Button(root, text="Générer la carte", command=generate_map)
generate_button.grid(row=3, column=0, columnspan=2, pady=10)

# Charger les données pour remplir la liste déroulante
load_data()

# Lancer l'interface
root.mainloop()
